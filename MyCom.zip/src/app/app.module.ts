import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";

import { AppComponent } from "./app.component";
import { HeaderComponent } from "./header/header.component";
import { CategoriesComponent } from "./categories/categories.component";
import { PopularProductsComponent } from "./popular-products/popular-products.component";
import { ShopdataService } from "./shopdata.service";

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    CategoriesComponent,
    PopularProductsComponent
  ],
  imports: [BrowserModule, HttpClientModule],
  providers: [ShopdataService],
  bootstrap: [AppComponent]
})
export class AppModule {}
