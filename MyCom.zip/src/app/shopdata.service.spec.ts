import { TestBed, inject } from '@angular/core/testing';

import { ShopdataService } from './shopdata.service';

describe('ShopdataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ShopdataService]
    });
  });

  it('should be created', inject([ShopdataService], (service: ShopdataService) => {
    expect(service).toBeTruthy();
  }));
});
