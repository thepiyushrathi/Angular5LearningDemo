import { Component, OnInit } from '@angular/core';
import { ShopdataService } from './shopdata.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  private homePageData: any;
  headerLinksData;
  title = 'app';
  constructor(private svc: ShopdataService) {}
  ngOnInit() {
    let categoriesData;
    let trendinData;
    this.svc.getHomeData().subscribe(data => {
      this.homePageData = data;
      console.log('dsdadscasda');
      console.log(this.homePageData);
      this.headerLinksData = this.homePageData.headerLinks;
      categoriesData = this.homePageData.shopCategories;
      trendinData = this.homePageData.popularProducts;
    });
  }
}
